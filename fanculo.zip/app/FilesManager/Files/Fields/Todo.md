## Date 
- [] should have button and when i click on button it shold dispaly callendar

## Image
- [x] Looks broken like we add some by default

# URL 
- [x] Should have only link attribute not text

## Rich text
- [x] Remove it as it should be inline like inner blocks

## Select
- [x] Breaks block